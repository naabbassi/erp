# README #

This README would normally document whatever steps are necessary to get your application up and running.

ERP for private using

* the small ERP to using for managment and organisation private activities that their responsibility is over myself
* Version 1.0
* to write this ERP we using codeigniter framework

Address : Kurdistan region government , Erbil , Gullan St , Sofy mall , No 58
Phone No : +964 750 827 3597