<?php
class group_accounts_model extends My_model{

	function __construct()
	{
		$this->table='group_accounts';
	}
}
?>