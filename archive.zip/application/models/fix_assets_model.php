<?php
class fix_assets_model extends My_model{

	function __construct()
	{
		$this->table='fix_assets';
	}
}
?>