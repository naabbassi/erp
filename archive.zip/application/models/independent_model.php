<?php
class independent_model extends My_model{

	function __construct()
	{
		$this->table='independent';
	}
}
?>