<?php
class purchase_details_model extends My_model{

	function __construct()
	{
		$this->table='purchase_details';
	}
}
?>