<?php
class owners_model extends My_model{

	function __construct()
	{
		$this->table='owners';
	}
}
?>