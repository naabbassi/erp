<?php
class accounting_record_model extends My_model{

	function __construct()
	{
		$this->table='accounting_record';
	}
}
?>