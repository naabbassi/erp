<?php
class unit_model extends My_model{

	function __construct()
	{
		$this->table='unit';
	}
}
?>