<?php
class sale_back_model extends My_model{

	function __construct()
	{
		$this->table='sale_back';
	}
}
?>